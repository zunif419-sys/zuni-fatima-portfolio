# Freelance Portfolio Website

A static site (HTML, CSS, vanilla JS) ready for GitHub Pages. No build step, no backend.

## Customise in 5 minutes
1. **Name, email, WhatsApp, location, social links, form service**: edit `js/config.js`.
2. **Page titles and SEO tags**: search all `.html` files for `Your Name` and replace it with your name (the visible logo, footer and page text update automatically from `config.js`, but titles and meta tags are static for search engines).
3. **Canonical URLs, Open Graph, robots.txt, sitemap.xml**: replace `YOUR-USERNAME` and `portfolio-website` with your GitHub username and repository name (use find-and-replace across all files).
4. **Photo**: replace `images/profile-placeholder.svg` (or change the `src` in the HTML) with your own image.
5. **Placeholders**: anything highlighted with a dotted underline (`class="ph"`) is placeholder text to edit or delete.
6. **Portfolio**: demo projects have a `Demo project` badge. Replace titles, images, and set `data-url="https://..."` on the View Project button to link to real work.
7. **Skill levels**: change `data-level="70"` in the skill bars to your own values.
8. **Testimonials**: replace the placeholder cards only with real client feedback.
9. **Social preview image**: replace `images/og-image.png` (1200x630) with your own.

## Contact form
- With `formEndpoint` empty, the form opens the visitor's email app (mailto fallback).
- To receive messages directly, create a free form at a service such as Formspree and paste its URL into `formEndpoint`.

## Deploy to GitHub Pages
1. Create a new public repository on GitHub, for example `portfolio-website`.
2. Upload all files from this folder to the repository root (drag and drop on github.com, or use git).
3. Go to **Settings > Pages**. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
4. After a minute your site is live at `https://YOUR-USERNAME.github.io/portfolio-website/`.
