/* Freelance Portfolio — script.js (vanilla JS, no dependencies) */
(function () {
  'use strict';
  var C = window.SITE_CONFIG || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Config -> page ---------- */
  function initials(n) {
    var p = String(n || '').trim().split(/\s+/);
    return ((p[0] || '').charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : '')).toUpperCase();
  }
  var text = {
    name: C.name, initials: initials(C.name), email: C.email,
    whatsapp: C.whatsappDisplay, location: C.location
  };
  $$('[data-site]').forEach(function (el) {
    var v = text[el.getAttribute('data-site')];
    if (v) el.textContent = v;
  });
  var hrefs = {
    mail: C.email ? 'mailto:' + C.email : '',
    whatsapp: C.whatsapp ? 'https://wa.me/' + C.whatsapp : '',
    linkedin: (C.socials || {}).linkedin, github: (C.socials || {}).github,
    instagram: (C.socials || {}).instagram, facebook: (C.socials || {}).facebook
  };
  $$('[data-href]').forEach(function (el) {
    var k = el.getAttribute('data-href'), v = hrefs[k];
    if (v) {
      el.setAttribute('href', v);
      if (/^https?:/.test(v) && k !== 'whatsapp') { el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener noreferrer'); }
    } else if (k !== 'whatsapp') {
      el.hidden = true;
    }
  });
  if (C.name && C.name !== 'Your Name') {
    document.title = document.title.replace(/Your Name/g, C.name);
  }
  var yr = $('#year'); if (yr) yr.textContent = new Date().getFullYear();

  /* ---------- Theme toggle (saved in localStorage) ---------- */
  var root = document.documentElement;
  var themeBtn = $('#theme-toggle');
  function setTheme(t) {
    root.setAttribute('data-theme', t);
    try { localStorage.setItem('theme', t); } catch (e) {}
    if (themeBtn) themeBtn.setAttribute('aria-pressed', t === 'dark');
  }
  if (themeBtn) {
    themeBtn.setAttribute('aria-pressed', root.getAttribute('data-theme') === 'dark');
    themeBtn.addEventListener('click', function () {
      setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    });
  }

  /* ---------- Sticky header + back to top ---------- */
  var hdr = $('.hdr'), topBtn = $('#to-top');
  function onScroll() {
    var y = window.pageYOffset || 0;
    if (hdr) hdr.classList.toggle('scrolled', y > 10);
    if (topBtn) topBtn.classList.toggle('show', y > 600);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  if (topBtn) topBtn.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  });

  /* ---------- Mobile menu ---------- */
  var menuBtn = $('#menu-btn'), nav = $('#site-nav');
  function closeMenu() {
    if (!nav) return;
    nav.classList.remove('open');
    if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
  }
  if (menuBtn && nav) {
    menuBtn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    $$('a', nav).forEach(function (a) { a.addEventListener('click', closeMenu); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });
    window.addEventListener('resize', function () { if (window.innerWidth > 960) closeMenu(); });
  }

  /* ---------- Scroll reveal + skill bars ---------- */
  var revealEls = $$('.rv'), bars = $$('.bar span');
  bars.forEach(function (b) {
    var lv = parseInt(b.getAttribute('data-level'), 10);
    if (!isNaN(lv)) {
      lv = Math.max(0, Math.min(100, lv));
      b.style.setProperty('--lv', lv + '%');
      var pct = b.parentNode.parentNode.querySelector('.pct');
      if (pct) pct.textContent = lv + '%';
    }
  });
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    revealEls.concat(bars).forEach(function (el) { io.observe(el); });
  } else {
    revealEls.concat(bars).forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- FAQ accordion ---------- */
  $$('.faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') === 'true';
      var panel = document.getElementById(btn.getAttribute('aria-controls'));
      btn.setAttribute('aria-expanded', open ? 'false' : 'true');
      if (panel) panel.hidden = open;
    });
  });

  /* ---------- Portfolio filter + project dialog ---------- */
  var filters = $$('.filter');
  filters.forEach(function (f) {
    f.addEventListener('click', function () {
      var cat = f.getAttribute('data-filter');
      filters.forEach(function (x) { x.setAttribute('aria-pressed', x === f ? 'true' : 'false'); });
      $$('[data-cat]').forEach(function (card) {
        card.hidden = !(cat === 'all' || card.getAttribute('data-cat') === cat);
      });
    });
  });
  var dlg = $('#project-dialog');
  $$('[data-project]').forEach(function (b) {
    b.addEventListener('click', function () {
      var url = b.getAttribute('data-url');
      if (url) { window.open(url, '_blank', 'noopener'); return; }
      if (dlg && dlg.showModal) {
        $('#pd-title', dlg).textContent = b.getAttribute('data-project');
        dlg.showModal();
      } else {
        window.alert('Demo project. Add a real link in the data-url attribute of this button.');
      }
    });
  });
  if (dlg) $$('[data-close]', dlg).forEach(function (c) { c.addEventListener('click', function () { dlg.close(); }); });

  /* ---------- Contact forms ---------- */
  var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  $$('.contact-form').forEach(function (form) {
    var status = $('.form-status', form);
    var params = new URLSearchParams(window.location.search);
    var pre = params.get('service'), sel = form.elements.service;
    if (pre && sel) {
      Array.prototype.forEach.call(sel.options, function (o) { if (o.value === pre) sel.value = pre; });
    }
    function say(msg) { if (status) { status.textContent = msg; status.classList.add('show'); } }
    function setErr(name, msg) {
      var f = form.elements[name], e = $('[data-err="' + name + '"]', form);
      if (f) f.setAttribute('aria-invalid', msg ? 'true' : 'false');
      if (e) e.textContent = msg || '';
    }
    function validate() {
      var f = form.elements, ok = true;
      var checks = [
        ['name', f.name.value.trim().length >= 2, 'Please enter your name.'],
        ['email', emailRe.test(f.email.value.trim()), 'Please enter a valid email address.'],
        ['service', !!f.service.value, 'Please choose a service.'],
        ['message', f.message.value.trim().length >= 10, 'Please write at least 10 characters.']
      ];
      checks.forEach(function (c) { setErr(c[0], c[2] && !c[1] ? c[2] : ''); if (!c[1]) ok = false; });
      return ok;
    }
    function summary() {
      var f = form.elements;
      return 'Name: ' + f.name.value.trim() + '\nEmail: ' + f.email.value.trim() +
        '\nService: ' + f.service.value + (f.budget.value.trim() ? '\nBudget: ' + f.budget.value.trim() : '') +
        '\n\n' + f.message.value.trim();
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (status) status.classList.remove('show');
      if (!validate()) { var bad = $('[aria-invalid="true"]', form); if (bad) bad.focus(); return; }
      if (form.elements._gotcha && form.elements._gotcha.value) return;
      if (C.formEndpoint) {
        var btn = $('button[type=submit]', form); if (btn) btn.disabled = true;
        fetch(C.formEndpoint, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
          .then(function (r) {
            if (r.ok) { form.reset(); say('Thank you. Your message has been sent and I will reply by email.'); }
            else { say('Sorry, the message could not be sent. Please email me directly or use WhatsApp.'); }
          })
          .catch(function () { say('Network problem. Please email me directly or use WhatsApp.'); })
          .then(function () { if (btn) btn.disabled = false; });
      } else {
        var subject = 'Project inquiry: ' + form.elements.service.value;
        window.location.href = 'mailto:' + (C.email || '') + '?subject=' + encodeURIComponent(subject) +
          '&body=' + encodeURIComponent(summary());
        say('Your email app should open with your message ready to send. If it does not, email me at ' + (C.email || 'the address above') + '.');
      }
    });
    var wa = $('[data-wa]', form);
    if (wa) wa.addEventListener('click', function () {
      if (!C.whatsapp) { say('WhatsApp is not set up yet. Add your number in js/config.js.'); return; }
      var f = form.elements, hasInfo = f.name.value.trim() && f.message.value.trim();
      var msg = hasInfo ? 'Hi! ' + summary() : 'Hi! I would like to ask about your services.';
      window.open('https://wa.me/' + C.whatsapp + '?text=' + encodeURIComponent(msg), '_blank', 'noopener');
    });
  });
  $$('[data-wa-link]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      if (!C.whatsapp) { e.preventDefault(); window.alert('WhatsApp is not set up yet. Add your number in js/config.js.'); return; }
      a.setAttribute('href', 'https://wa.me/' + C.whatsapp + '?text=' + encodeURIComponent('Hi! I would like to ask about your services.'));
      a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener');
    });
  });
})();
