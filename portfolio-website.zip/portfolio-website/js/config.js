/* ==========================================================
   SITE CONFIGURATION: edit this one file to personalise the site.
   ========================================================== */
window.SITE_CONFIG = {
  // Your personal brand name. Shown in the logo, footer and page titles.
  name: "Your Name",

  // Contact details
  email: "hello@example.com",
  whatsapp: "",                       // digits only, with country code, e.g. "923001234567"
  whatsappDisplay: "+00 000 000 0000", // how the number is shown on the page
  location: "City, Country",

  // Social links. Leave empty ("") to hide an icon.
  socials: {
    linkedin: "",
    github: "",
    instagram: "",
    facebook: ""
  },

  // Contact form delivery:
  //  - Leave formEndpoint empty to use the mailto fallback (opens the visitor's email app).
  //  - Or paste a form-service URL (for example a Formspree endpoint like
  //    "https://formspree.io/f/xxxxxxxx") to receive submissions by email.
  formEndpoint: ""
};
